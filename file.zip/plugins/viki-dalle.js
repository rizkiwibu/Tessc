const fetch = require('node-fetch')

let handler = async (m, { conn, text, command }) => {
  if (!text) throw 'Masukkan teks untuk membuat gambar'
  conn.reply(m.chat, 'Tunggu sebentar yah kak..', m)
  let url = `https://api.lolhuman.xyz/api/dall-e?apikey=ayakaviki&text=${text}`
  let response = await fetch(url)
  let result = await response.buffer()
  conn.sendFile(m.chat, result, 'dalle.jpg', 'Nih kak', m)
}

handler.command = /^(dalle|aidalle|openaiimage)$/i
handler.help = ['dalle <teks>', 'aidalle <teks>', 'openaiimage <teks>']
handler.tags = ['premium']
handler.premium = true
handler.limit = true
handler.premium = false
handler.register = true

module.exports = handler