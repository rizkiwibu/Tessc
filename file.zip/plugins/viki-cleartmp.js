/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const { tmpdir } = require('os');
const path = require('path');
const {
  readdirSync,
  statSync,
  unlinkSync,
} = require('fs');

let handler = async (m, { conn }) => {
  conn.reply(m.chat, 'Success!', m);

  const tmp = [tmpdir(), path.join(process.cwd(), 'tmp')];
  const filename = [];
  tmp.forEach((dirname) => {
    readdirSync(dirname).forEach((file) => {
      filename.push(path.join(dirname, file));
    });
  });
  
  return filename.map((file) => {
    const stats = statSync(file);
    unlinkSync(file);
  });
};

handler.help = ['cleartmp'];
handler.tags = ['owner'];
handler.command = /^cleartmp$/i;
handler.owner = true;

module.exports = handler;