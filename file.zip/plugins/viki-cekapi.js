/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */

const axios = require('axios')


const handler = async (m, { text }) => {

  if (!text) return conn.reply(m.chat, 'Masukan apikey nya kak..', m)
  m.reply('Tunggu sebentar...')

  try {
    const response = await axios.get(`https://api.lolhuman.xyz/api/checkapikey?apikey=${text}`)
    const { status, message, result } = response.data
    if (status === 200 && message === 'success') {
      const { username, requests, today, account_type, expired } = result
      const text = `API Key Information\n\nUsername: ${username}\nTotal Requests: ${requests}\nRequests Today: ${today}\nAccount Type: ${account_type}\nExpired: ${expired}`
      m.reply(text)
    } else {
      m.reply('Terjadi kesalahan saat memproses permintaan.')
    }
  } catch (e) {
    console.log(e)
    m.reply('Terjadi kesalahan saat memproses permintaan.')
  }
}

handler.help = ['cekapi <API Key>', 'cekapikey <API Key>']
handler.tags = ['tools']
handler.command = /^(cekapi|cekapikey)$/i
handler.register = true
handler.limit = true

module.exports = handler