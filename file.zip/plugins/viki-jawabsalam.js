/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let handler = async (m, { conn }) => {
  let regex = /^(assalamualaikum|salam|ass|salo?m|p)$/i
  if (regex.test(m.text)) {
    let sender = await conn.getName(m.sender)
    let caption = `Waalaikumsalam *${sender}*. Say your greetings to people when you meet them, if they respond, then the angels will return the greetings for you and for them, but if they do not respond, then the angels will return the greetings for you and may even curse or ignore them.`
    conn.sendMessage(m.chat, {
      text: caption,
      contextInfo: {
        externalAdReply: {
          title: `${global.namebot}`,
          body: "Allah for everything",
          thumbnailUrl: "https://cdn.jsdelivr.net/gh/SazumiVicky/MakeMeow-Storage@main/20230601_094242.jpg",
          sourceUrl: "https://instagram.com/moe.sazumiviki",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      },
      quoted: m
    }, {
      sendEphemeral: true,
      quoted: m
    })
  }
}

handler.command = /.*/
handler.customPrefix = /^(assalamualaikum|salam|ass|salo?m)$/i
handler.exp = 0

module.exports = handler
