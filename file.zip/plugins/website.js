/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let handler = async m => {

let krtu = `web`
m.reply(`
> https://sazumiviki.me
> https://ayaka.sazumiviki.me
> https://dgthuthao.com
`.trim()) 
}
handler.command = /^(web)$/i
handler.register = true
handler.limit = true

module.exports = handler