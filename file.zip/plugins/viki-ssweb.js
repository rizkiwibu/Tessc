/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const axios = require('axios');

let handler = async (m, { text }) => {
  if (!text) {
    return m.reply('*Example*: .ssweb https://sazumiviki.me');
  }

  try {
    let apiUrl = `https://api.lolhuman.xyz/api/ssweb?apikey=ayakaviki&url=${encodeURIComponent(text)}`;

    await m.reply('Wait a moment...');

    let response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

    if (response.status === 200) {
      await conn.sendFile(
        m.chat,
        response.data,
        'screenshot.jpg',
        'Here is the requested screenshot of the website.'
      );
    } else {
      m.reply('Sorry, unable to take a screenshot of the website.');
    }
  } catch (error) {
    console.log(error);
    m.reply('An error occurred while taking a screenshot of the website.');
  }
};

handler.help = ['ssweb <link>'];
handler.tags = ['tools'];
handler.command = /^ssweb$/i;

module.exports = handler;
