/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const axios = require('axios');

let handler = async (m, { conn, text }) => {
  if (!text) {
    throw '*Example*: .diffusions girl, pizza'
  }

  let prompt = encodeURIComponent(text);
  let api = `https://api.lolhuman.xyz/api/diffusion-prompt?apikey=ayakaviki&prompt=${prompt}`;

  try {
    m.reply('Generating image...');
    let { data } = await axios.get(api, { responseType: 'arraybuffer' });

    conn.sendFile(m.chat, data, 'diffusion.jpg', '', m);
  } catch (error) {
    throw 'An error occurred while fetching the diffusion image. Please try again later.';
  }
};

handler.help = ['diffusions'];
handler.tags = ['tools'];
handler.command = /^diffusions?$/i;

module.exports = handler;
