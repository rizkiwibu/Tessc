/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let handler = async (m, { conn }) => {
    if (!global.db.data.users[m.sender]?.email) {
      return conn.reply(m.chat, 'Anda belum terverifikasi dengan email', m)
    }
  
    let email = global.db.data.users[m.sender].email
    delete global.db.data.users[m.sender].email
    delete global.db.data.usedEmails?.[email]
  
    conn.reply(m.chat, 'Verifikasi email berhasil dihapus. Silakan verifikasi email Anda lagi dengan perintah .regmail <email>', m)
  }
  
  handler.help = ['delverify']
  handler.tags = ['info']
  handler.command = /^(delverify)$/i
  handler.owner = false
  handler.mods = false
  handler.premium = false
  
  handler.exp = 0
  handler.limit = true
  
  module.exports = handler