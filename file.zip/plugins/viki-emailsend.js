/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const nodemailer = require('nodemailer')

let transporter = nodemailer.createTransport({
  service: 'Zoho',
  auth: {
    user: 'hi@sazumiviki.me',
    pass: '3B82EGvXQgfx'
  }
})

let handler = async (m, { text }) => {
  let msg = text.trim()
  if (!msg) return m.reply('Silakan masukkan email penerima dan pesan yang ingin dikirim.\nContoh: .email hi@example.com | Ini adalah pesan yang akan dikirim.')

  let parts = msg.split('|')
  if (parts.length < 2) return m.reply('Silakan masukkan email penerima dan pesan yang ingin dikirim.\nContoh: .email hi@example.com | Ini adalah pesan yang akan dikirim.')

  let to = parts[0].trim()
  let message = parts.slice(1).join('|').trim()

  let mailOptions = {
    from: 'hi@sazumiviki.me',
    to: to,
    subject: 'From Ayaka Ai',
    text: message
  }

  m.reply('Tunggu sebentar yah kak..')
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log(error)
      m.reply('Gagal mengirim email.')
    } else {
      console.log('Email terkirim: ' + info.response)
      m.reply('Email berhasil dikirim ke ' + to + '.')
    }
  })
}

handler.help = ['email <email penerima> | <pesan>']
handler.tags = ['owner']
handler.command = /^email$/i
handler.owner = true

module.exports = handler