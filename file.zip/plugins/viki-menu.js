/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let axios = require('axios')

let handler = async (m, { conn, text }) => {
  let user = global.db.data.users[m.sender]
  let name = conn.getName(m.sender)
  let time = new Date().getHours()
  let greeting = ''
  if (time >= 0 && time < 4) {
    greeting = '👋 Good night'
  } else if (time >= 4 && time < 12) {
    greeting = '👋 Good morning'
  } else if (time >= 12 && time < 18) {
    greeting = '👋 Good afternoon'
  } else if (time >= 18 && time < 24) {
    greeting = '👋 Good evening'
  }
  let mainmenu = `${greeting} *@${user.name}*, Ayaka is a WhatsApp bot that you can use as a tool to make *stickers*, listen to *music*, and play *RPG games* in real-time.

Ayaka is also a bot that strictly maintains the *privacy* of its users. The data stored on Ayaka will be *destroyed* every week, so your data will not be seen by anyone.

My big boss *Sazumi Viki* [+6285236226786].

◦ *.Allmenu* - Show all menu.
◦ *.About* - Show about Ayaka.`

  let thumbnailUrl = "https://cdn.jsdelivr.net/gh/SazumiVicky/MakeMeow-Storage@main/20230527_112621.jpg"
  let sourceUrl = "https://sazumiviki.me"

  conn.reply(m.chat, mainmenu, m, {
    contextInfo: {
      externalAdReply: {
        title: `Ayaka Ai - MakeMeow`,
        body: "",
        thumbnailUrl: thumbnailUrl,
        sourceUrl: sourceUrl,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  })

  let songUrl = 'https://e.top4top.io/m_2703kkbxo1.mp3'
  let res2 = await axios.get(songUrl, { responseType: 'arraybuffer' })
  await conn.sendFile(m.chat, Buffer.from(res2.data), 'song.mp3', '', m)
}

handler.command = /^menu$/i
handler.help = ['menu']
handler.tags = ['main']
handler.register = true
handler.limit = true

module.exports = handler
