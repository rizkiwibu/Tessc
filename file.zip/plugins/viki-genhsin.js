const axios = require('axios')

let handler = async (m, { conn, text }) => {
  if (!text) {
    return conn.reply(m.chat, 'Mohon masukkan nama karakter Genshin Impact yang ingin Anda ketahui', m)
  }
  let response = await axios.get(`https://api.lolhuman.xyz/api/genshin/${text}?apikey=ayakaviki`)
  let result = response.data.result
  if (response.data.status != 200) {
    return conn.reply(m.chat, 'Maaf, karakter yang Anda cari tidak ditemukan', m)
  }
  let message = `*${result.title}*\n\n${result.intro}`
  conn.sendFile(m.chat, result.icon, 'icon.jpg', message, m)
}

handler.help = ['genshin <teks>']
handler.tags = ['game']
handler.command = /^genshin$/i
handler.register = true
handler.limit = true

module.exports = handler