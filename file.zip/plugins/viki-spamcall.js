/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let fetch = require('node-fetch')

let handler = async (m, { conn, text, usedPrefix }) => {

  if (!text) throw `Contoh Penggunaan\n${usedPrefix}spamcall 628xxxxxxxx`

  let nomor = text.replace(/[^0-9]/gi, '').slice(2)

  if (!nomor.startsWith('8')) throw `Contoh Penggunaan\n${usedPrefix}spamcall 628xxxxxxxx`
  
  m.reply('Tunggu Sebentar...')

  let anu = await fetch(`https://api.lolhuman.xyz/api/spam/call1?apikey=ayakaviki&nomor=${text}`).then(a => a.json())
  
  let spcall = `*Nomor* : ${nomor}\n\nAyaka berhasil menelpon anda!`
  
  conn.reply(m.chat, `${spcall}`.trim(), m)

}

handler.help = ['spamcall <nomor>']

handler.tags = ['tools']

handler.command = /^(spamcall)$/i

handler.register = true
handler.limit = true
handler.premium = false
handler.group = false

module.exports = handler