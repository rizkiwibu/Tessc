const axios = require('axios')

let handler = async (m, { args }) => {
  let url = args[0]
  if (!url || !url.match(/^https:\/\/sfile\.mobi\/(.+)$/i)) {
    return m.reply('*Example*: .sfiledl https://sfile.mobi/xxxxx')
  }

  let apiUrl = `https://xzn.wtf/api/sfiledl?url=${encodeURIComponent(url)}&apikey=nakanosky`
  try {
    let { data } = await axios.get(apiUrl)
    if (data.status == 'success') {
      let fileUrl = data.url
      let fileName = data.name
      let fileSize = data.size
      let uploadBy = data.uploadBy
      let uploadDate = data.uploadDate
      let downloads = data.downloads

      m.reply('Wait a moment...')
      conn.sendFile(m.chat, fileUrl, fileName, `• Nama: ${fileName}\n• Ukuran: ${fileSize}\n• Diunggah oleh: ${uploadBy}\n• Tanggal unggah: ${uploadDate}\n• Jumlah unduhan: ${downloads}`, m)
    } else {
      m.reply('Failed to get download link')
    }
  } catch (e) {
    console.log(e)
    m.reply('An error occurred while processing the request')
  }
}

handler.help = ['sfiledl <sfile_link>']
handler.tags = ['downloader']
handler.command = /^sfiledl$/i

module.exports = handler