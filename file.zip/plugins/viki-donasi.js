/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let handler = async (m, { conn }) => {
  let caption = `◦ Dana: 089678063142\n◦ Pulsa: 085236226786\n◦ Pulsa: 089678063142\n\nThank you for donating support to the Ayaka bot. Your contribution means a lot to us to continue to improve the quality of the services we provide. We really appreciate your help. Thank You!`
  
  m.reply(caption, null, {
    contextInfo: {
      externalAdReply: {
        title: `${global.namebot}`,
        body: "",
        thumbnailUrl: "https://cdn.jsdelivr.net/gh/SazumiVicky/MakeMeow-Storage@main/20230531_124152.jpg",
        sourceUrl: "https://sazumiviki.me",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
}

handler.help = ['donasi', 'sedekah']
handler.tags = ['info']
handler.premium = false
handler.command = /^(donasi|sedekah)$/i

module.exports = handler;
