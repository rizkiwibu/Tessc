/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const fetch = require('node-fetch')

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, 'Silahkan masukkan nama nabi', m)
  
  let res = await fetch(`https://api.lolhuman.xyz/api/kisahnabi/${text}?apikey=ayakaviki`)
  let json = await res.json()

  if (json.error) return conn.reply(m.chat, json.error, m)

  let message = `
*Nama Nabi:* ${json.result.name}
*Tahun Kelahiran:* ${json.result.thn_kelahiran}
*Usia:* ${json.result.age}
*Tempat Lahir:* ${json.result.place}
*Kisah:* ${json.result.story}
`

  let img = 'https://cdn.jsdelivr.net/gh/SazumiVicky/Storage@main/IMG_20230430_192107_543.jpg'
  
  conn.sendFile(m.chat, img, 'kisahnabi.jpg', message.trim(), m)
}

handler.help = ['kisahnabi <nama nabi>']
handler.tags = ['islam']
handler.command = /^(kisahnabi)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false
handler.register = true

handler.fail = null
handler.limit = true

module.exports = handler