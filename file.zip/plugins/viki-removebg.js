/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const axios = require('axios');
const FormData = require('form-data');

let handler = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';

  if (/image/.test(mime)) {
    conn.reply(m.chat, '🐱 Wait a moment...', m);

    let img = await q.download();
    let formData = new FormData();
    formData.append('image_file', img, 'image.jpg');

    try {
      let res = await axios.post('https://api.remove.bg/v1.0/removebg', formData, {
        headers: {
          'X-Api-Key': 'H4s3MgjbNCQGqgiTp74qw8Us',
          ...formData.getHeaders()
        },
        responseType: 'arraybuffer'
      });

      let resultImage = Buffer.from(res.data, 'binary');

      conn.sendFile(m.chat, resultImage, 'removed_bg.png', '🐱 Successfully removed the background of the image', m);
    } catch (error) {
      console.log(error);
      conn.reply(m.chat, '🐱 An error occurred while processing the image. Please make sure the image quality is good and try again later.\n\nError details: ' + error.message, m);
    }
  } else {
    conn.reply(m.chat, '🐱 Please reply to the image you want to remove the background with the caption *.removebg*', m);
  }
};

handler.help = ['removebg *reply image*'];
handler.tags = ['premium'];
handler.premium = true
handler.command = /^removebg$/i;

module.exports = handler;
