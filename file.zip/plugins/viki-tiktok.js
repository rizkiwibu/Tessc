var api = require('api-dylux');
async function handler(m, {
 text, 
 usedPrefix, 
 command
 }) {   
  if (!text) throw `Masukan URL Tiktok\n\n*Example:* ${ usedPrefix + command} https://tiktok.com/xxxx`
  await m.reply('Tunggu Sebentar...')
  api.tiktok(text)
  .then(res => conn.sendFile(m.chat, res.hdplay, 'tiktok.mp4', '', m))
  .catch(console.error);
}        
handler.command = handler.help = ['tiktok', 'tt', 'ttdl']
handler.tags = ['downloader']
handler.limit = true

module.exports = handler