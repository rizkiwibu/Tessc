const fetch = require('node-fetch');
const uploadImage = require('../lib/uploadImage.js');

const handler = async (m, { conn, usedPrefix, command, text }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (!mime) throw 'Kirim/Reply Gambar dengan caption .makerdiff';
  conn.reply(m.chat, 'Tunggu Sebentar...', m);
  let media = await q.download();
  let url = await uploadImage(media);

  // Memuat hasil untuk tiga gaya anime yang berbeda
  let results = await Promise.all([
    fetch(`https://api.itsrose.site/image/differentMe?url=${url}&style=anime&apikey=197d9e23646230b6b01d37d3`).then(res => res.buffer()),
    fetch(`https://api.itsrose.site/image/differentMe?url=${url}&style=angel&apikey=197d9e23646230b6b01d37d3`).then(res => res.buffer()),
    fetch(`https://api.itsrose.site/image/differentMe?url=${url}&style=cat_ears&apikey=197d9e23646230b6b01d37d3`).then(res => res.buffer())
  ]);

  // Mengirimkan hasil ke masing-masing gaya anime
  await Promise.all([
    conn.sendFile(m.chat, results[0], '', 'Style: Anime', m), // gaya angel
    conn.sendFile(m.chat, results[1], '', 'Style: Angel', m), // gaya cg
    conn.sendFile(m.chat, results[2], '', 'Style: Cat Ears', m)  // gaya manhwa_male
  ]);
};

handler.help = ['makerdiff'];
handler.tags = ['internet'];
handler.command = /^makerdiff|makerdif$/i;
handler.limit = true;

module.exports = handler;