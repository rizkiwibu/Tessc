/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const axios = require('axios');

let handler = async (m, { conn, text }) => {
  if (!text) throw '*Example*: .ai how to get a girlfriend.';

  try {
    conn.reply(m.chat, 'Wait a moment...', m);

    const apiEndpoint = `https://api.lolhuman.xyz/api/openai?apikey=ayakaviki&text=${encodeURIComponent(text)}&user=user-unique-id`;
    const { data } = await axios.get(apiEndpoint);

    const answer = data.result;

    conn.reply(m.chat, `*Question*: ${text}\n\n*Answer*: ${answer}`, m, {
      contextInfo: {
        externalAdReply: {
          title: `Ayaka Ai - MakeMeow`,
          body: "",
          thumbnailUrl: "https://cdn.jsdelivr.net/gh/SazumiVicky/MakeMeow-Storage@main/20230531_103434.jpg",
          sourceUrl: "https://sazumiviki.me",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    });
  } catch (error) {
    console.error(error);
    conn.reply(m.chat, '🐱 An error occurred while processing the AI request.', m);
  }
};

handler.help = ['ai'];
handler.tags = ['internet'];
handler.command = /^ai/i;

module.exports = handler;

