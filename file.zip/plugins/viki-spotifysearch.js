/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let fetch = require('node-fetch');

let handler = async (m, { conn, command, usedPrefix, text }) => {
  if (!text) {
    throw `Ketik ${usedPrefix + command} judul lagu dan penyanyinya 

Contoh : ${usedPrefix + command} oh asmara kobo kanaeru`;
  }

  conn.reply(m.chat, 'Tunggu sebentar...', m);

  const response = await fetch(`https://myvin.me/spotify/play?q=${text}`);
  if (!response.ok) {
    throw `Gagal memanggil API: ${response.statusText}`;
  }

  const buffer = await response.buffer();
  conn.sendFile(m.chat, buffer, 'audio.mp3', '', m, 0, { mimetype: 'audio/mp4' });
};

handler.help = handler.command = ['spotifysearch'];
handler.tags = ['premium'];
handler.premium = true
handler.register = true;
handler.limit = true;
handler.premium = false;

module.exports = handler;