/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const axios = require('axios');
const FormData = require('form-data');

let handler = async (m, { conn, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  if (/image/.test(mime)) {
    let img = await q.download();
    let formData = new FormData();
    formData.append('image', img, 'image.jpg');
    try {
      let res = await axios.post('https://api.imgbb.com/1/upload', formData, {
        params: {
          key: '32dccc1da5b49fc9ed09fd6d9e691d40'
        },
        headers: formData.getHeaders()
      });
      let imageUrl = res.data.data.url;
      let api = `https://api.neoxr.my.id/api/recolor?image=${encodeURIComponent(imageUrl)}&apikey=lucycat`;

      conn.reply(m.chat, 'Wait a moment...', m);

      let { data } = await axios.get(api);
      let recoloredImageUrl = data.data.url;
      conn.sendFile(m.chat, recoloredImageUrl, 'recolor.jpg', '🐱 Here is the recolored image:', m);
    } catch (e) {
      console.log(e);
      conn.reply(m.chat, 'Error!', m);
    }
  } else {
    conn.reply(m.chat, '🐱 Please reply to the image', m);
  }
}

handler.command = /^(recolor|warnain)$/i;
handler.tags = ['tools'];
handler.help = ['recolor', 'warnain'];
handler.premium = false;

module.exports = handler;
