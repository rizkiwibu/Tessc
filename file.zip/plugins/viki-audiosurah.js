/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let handler = async (m, { conn, text }) => {
  if (!text) {
    return conn.reply(m.chat, 'Silakan masukkan nomor surah dan ayat yang ingin kamu dengarkan', m)
  }
  let apikey = 'ayakaviki'
  let url = `https://api.lolhuman.xyz/api/quran/audio/${encodeURIComponent(text)}?apikey=${apikey}`
  conn.reply(m.chat, 'Tunggu sebentar yah kak.', m)
  conn.sendFile(m.chat, url, 'audio.mp3', '', m, true)
}

handler.help = ['audiosurah <nomor_surah>:<nomor_ayat>']
handler.tags = ['islam']
handler.command = /^audiosurah$/i
handler.register = true
handler.limit = true

module.exports = handler