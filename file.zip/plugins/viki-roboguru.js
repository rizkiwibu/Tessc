/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const fetch = require('node-fetch')

let handler = async (m, { conn, command, args }) => {
  if (!args[0]) {
    return conn.reply(m.chat, '*Example*: .roboguru 1+1', m)
  }
  let apikey = 'ayakaviki'
  let query = encodeURIComponent(args.join(' '))
  let grade = 'sma'
  let subject = 'sejarah'
  let url = `https://api.lolhuman.xyz/api/roboguru?apikey=${apikey}&query=${query}&grade=${grade}&subject=${subject}`
  await conn.reply(m.chat, 'Wait a moment..', m)
  let res = await fetch(url)
  let json = await res.json()
  if (json.status !== 200) {
    return conn.reply(m.chat, 'Sorry, there was an error fetching data from the server', m)
  }
  let result = json.result
  if (result.length === 0) {
    return conn.reply(m.chat, 'Sorry, couldn t find an answer to that question', m)
  }
  let answer = result[0].answer
  let message = `*Pertanyaan:* ${result[0].question}\n\n*Jawaban:* ${answer}`
  conn.reply(m.chat, message, m)
}

handler.help = ['roboguru <teks>']
handler.tags = ['tools']
handler.command = /^(roboguru)$/i
handler.register = true
handler.limit = true

module.exports = handler