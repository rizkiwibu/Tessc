/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const axios = require('axios');

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, '*Example*: .aiturbo how to get a girlfriend.', m);

  const api = `https://api.lolhuman.xyz/api/openai-turbo?apikey=ayakaviki&text=${encodeURIComponent(text)}&lang=id`;

  try {
    conn.reply(m.chat, 'Wait a moment...', m);
    const res = await axios.get(api);
    const result = res.data.result;
    const caption = `
*Question:* ${text}
*Answer:* ${result}
`;

    conn.reply(m.chat, caption, m, {
      contextInfo: {
        externalAdReply: {
          title: `${global.namebot}`,
          body: "",
          thumbnailUrl: "https://cdn.jsdelivr.net/gh/SazumiVicky/MakeMeow-Storage@main/20230531_103800.jpg",
          sourceUrl: "https://sazumiviki.me",
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    });
  } catch (e) {
    console.log(e);
    conn.reply(m.chat, '🐱 An error occurred while processing your request.', m);
  }
};

handler.help = ['aiturbo'];
handler.tags = ['internet'];
handler.command = /^aiturbo$/i;

module.exports = handler;
