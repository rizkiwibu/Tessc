const axios = require('axios')

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, 'Silakan masukkan link story Instagram yang ingin kamu unduh.', m)
  let username = /instagram\.com\/([a-zA-Z0-9_.]+)/.exec(text.toLowerCase())[1]
  let res = await axios.get(`https://api.lolhuman.xyz/api/igstory/${username}?apikey=ayakaviki`)
  let data = res.data.result[0]
  if (!data) return conn.reply(m.chat, 'Maaf, tidak ada story yang ditemukan untuk username ini', m)
  let caption = `*${data.username}*\n\nTanggal: ${data.date}\n\n`
  let media = []
  for (let item of data.storyitem) {
    if (item.type == "image") {
      media.push({ url: item.url, type: 'image', filename: `${data.username}_${item.id}.jpg` })
    } else if (item.type == "video") {
      media.push({ url: item.url, type: 'video', filename: `${data.username}_${item.id}.mp4` })
    }
  }
  conn.sendFile(m.chat, media[0], caption, m)
}

handler.help = ['igstory <link>']
handler.tags = ['downloader']
handler.command = ['igstory']
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false
handler.admin = false
handler.botAdmin = false
handler.fail = null
handler.register = true
handler.limit = true

module.exports = handler