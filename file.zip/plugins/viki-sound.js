/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


let axios = require('axios')

let handler = async (m, { conn }) => {
  let url = 'https://e.top4top.io/m_2663sezqf0.mp3'
  let res = await axios.get(url, { responseType: 'arraybuffer' })
  await conn.sendFile(m.chat, Buffer.from(res.data), 'song.mp3', '', m)
}

handler.command = /^menu$/i

module.exports = handler