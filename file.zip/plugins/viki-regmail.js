/* Owner: Sazumi Viki */
/* Asisten: Ayaka Ai */
/* Instagram: @moe.sazumiviki */
/* Facebook: Sazumi Viki */
/* Github: SazumiVicky */
/* Buy Sc Update: +6285236226786 */
/* Source Code: https://github.com/SazumiVicky/AyakaV2 */


const nodemailer = require('nodemailer')
const { v4: uuidv4 } = require('uuid')

let emailDatabase = {}

let transporter = nodemailer.createTransport({
  host: 'smtp.zoho.com',
  port: 465,
  secure: true,
  auth: {
    user: 'hi@sazumiviki.me',
    pass: '3B82EGvXQgfx'
  }
})

let sendVerificationCode = async (conn, m, email) => {
  try {
    let code = uuidv4().slice(0, 6)
    let mailOptions = {
      from: 'hi@sazumiviki.me',
      to: email,
      subject: 'Ayaka Ai Verification',
      text: `Your verification code is ${code}. This code is valid for 3 minutes.`
    }

    await transporter.sendMail(mailOptions)

    emailDatabase[m.sender] = { email, code, time: Date.now() }
    conn.reply(m.chat, `Kode konfirmasi telah dikirim ke email ${email}`, m)
  } catch (err) {
    console.log(err)
    conn.reply(m.chat, 'Gagal mengirim email verifikasi', m)
  }
}

let handler = async (m, { conn, text, command }) => {
    if (command === 'regmail') {
      if (!text) return conn.reply(m.chat, `*Example*: .regmail hi@sazumiviki.me`, m)
      
      let email = text.trim().toLowerCase()
      let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      
      if (!emailRegex.test(email)) return conn.reply(m.chat, 'Invalid email address', m)
  
      if (global.db.data.users[m.sender]?.email) {
        return conn.reply(m.chat, `Sorry, you have previously verified with an email address ${global.db.data.users[m.sender]?.email}`, m)
      }
  
      if (global.db.data.usedEmails?.[email]) {
        return conn.reply(m.chat, 'Sorry, this email address has already been used for verification', m)
      }
  
      if (!global.db.data.users[m.sender]) {
        global.db.data.users[m.sender] = {}
      }
  
      await sendVerificationCode(conn, m, email)
    } else if (command === 'code') {
      if (!text) return conn.reply(m.chat, `*Example*: .code 27238`, m)
  
      if (global.db.data.users[m.sender]?.email) {
        return conn.reply(m.chat, `Sorry, you have previously verified with an email address ${global.db.data.users[m.sender]?.email}`, m)
      }
  
      if (!global.db.data.users[m.sender]) {
        global.db.data.users[m.sender] = {}
      }
  
      let code = text.trim().toLowerCase()
      let data = emailDatabase[m.sender]
  
      if (!data) return conn.reply(m.chat, 'You haven t requested a verification code', m)
  
      if (code != data.code) return conn.reply(m.chat, 'Incorrect verification code', m)
  
      if (Date.now() - data.time > 3 * 60 * 1000) {
        delete emailDatabase[m.sender]
        return conn.reply(m.chat, 'The verification code has expired', m)
      }
  
      global.db.data.users[m.sender].email = data.email
  
      if (!global.db.data.usedEmails) {
        global.db.data.usedEmails = {}
      }
  
      global.db.data.usedEmails[data.email] = true
      delete emailDatabase[m.sender]
      conn.reply(m.chat, '🐱 Email verified successfully', m)
    }
  }

handler.help = ['regmail <email>', 'code <verification code>']
handler.tags = ['info']
handler.command = /^(regmail|code)$/i
handler.owner = false
handler.mods = false
handler.premium = false

handler.exp = 0
handler.limit = true

module.exports = handler